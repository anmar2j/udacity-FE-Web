# My Web App

Welcome to My Web App! This is a simple responsive landing page built with HTML, CSS, and JavaScript.

## Project Description

This project demonstrates how to create a responsive landing page with a fixed navigation bar, smooth scrolling to sections, and dynamic navigation menu. It also includes a "Scroll to Top" button and collapsible sections. The landing page adjusts its layout to provide a better user experience on different devices, such as modern desktops, tablets, and phones.

## Usage

To view the web page, simply open the `index.html` file in your web browser.

## Dependencies

This project does not have any external dependencies. It uses standard HTML, CSS, and JavaScript.

## How to Test

1. Clone or download this repository to your local machine.
2. Navigate to the project directory.
3. Open the `index.html` file in your web browser.
4. Interact with the navigation links to scroll to different sections on the page.
5. Observe the navigation menu updating to show the active section.
6. Scroll down to see the "Scroll to Top" button appear.

## License

This project is licensed under the [MIT License](LICENSE).

Feel free to modify and use this project as you like!

## Author

This project is created by [Anmar alghabshi](https://github.com/anmar2j).

If you have any questions or feedback, feel free to reach out!

