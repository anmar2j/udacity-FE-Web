const sectionsData = [
  {
    id: 'home',
    title: 'Home',
  },
  {
    id: 'about',
    title: 'About',
  },
  {
    id: 'services',
    title: 'Services',   
  },
  {
    id: 'contact',
    title: 'Contact',
  },
];
function isSectionInViewport(section) {
  const rect = section.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}

 //active state of the navigation
 function updateActiveNavLinks() {
  const navLinks = document.querySelectorAll('nav [data-section]');
   navLinks.forEach(link => {
    const sectionId = link.dataset.section;
    const section = document.getElementById(section);

    if (isSectionInViewport(section)) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

//create the navigation menu
function createNavigationMenu() {
  const navList = document.querySelector('nav ul');
  sectionsData.forEach(section => {
    const listItem = document.createElement('li');
    const link = document.createElement('a');
    link.href = `#${section.id}`;
    link.textContent = section.title;
    link.dataset.section = section.id;
    listItem.appendChild(link);
    navList.appendChild(listItem);
  });
}

// Function to handle intersection of sections with the viewport
function handleIntersection(entries) {
  entries.forEach(entry => {
    const sectionId = entry.target.getAttribute('id');
    const navLink = document.querySelector(`nav [data-section="${sectionId}"]`);

    if (entry.isIntersecting) {
      navLink.classList.add('active');
    } else {
      navLink.classList.remove('active');
    }
  });
}

// Function to scroll to the appropriate section
function scrollToSection(event) {
  event.preventDefault();

  const sectionId = event.target.dataset.section;
  const targetSection = document.getElementById(sectionId);

  targetSection.scrollIntoView({ behavior: 'smooth' });
}

// Set up the Intersection Observer
const observer = new IntersectionObserver(handleIntersection, {
  root: null,
  rootMargin: '0px',
  threshold: 0.5,
});

// Function to observe each section
function observeSections() {
  const sections = document.querySelectorAll('.content-section');
  sections.forEach(section => {
    observer.observe(section);
  });
}

// Call the necessary functions
document.addEventListener('DOMContentLoaded', () => {
  createNavigationMenu();
  observeSections();
  updateActiveNavLinks(); 

  const navLinks = document.querySelectorAll('nav [data-section]');
  navLinks.forEach(link => {
    link.addEventListener('click', scrollToSection);
  });

  // Update active navigation items on scroll
  window.addEventListener('scroll', updateActiveNavLinks);
});